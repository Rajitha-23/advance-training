export class Menu {
  menuName!: string;
  description!: string;
  price!: string;
  category!: string;
  imagesource!: string;
}