import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {
  loggedInUserId: number | null = null;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.loggedInUserId = parseInt(localStorage.getItem('loggedInUserId') || '0', 10);
  }

  logout() {
    this.router.navigate(['/home']);
  }

  navigateToContact() {
    this.router.navigate(['/contact']); 
  }

  navigateToBookatable() {
    this.router.navigate(['/bookatable']);
  }

  navigateToMenucard() {
    this.router.navigate(['/menu-card']);

  }

  navigateToChangepassword() {
    this.router.navigate(['/changepassword']);
    
  }

  navigateToUpdateprofile() {
    this.router.navigate(['/update-profile']);
    
  }

  navigateToWelcome() {
    this.router.navigate(['/welcome']);
    
  }




}

