import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.css']
})
export class AdminhomeComponent implements OnInit {

  constructor(private router: Router) {}

  ngOnInit(): void {
    
  }

  navigateToReservation() {
    this.router.navigate(['/reservation']);
  }

  navigateToMenutable() {
    this.router.navigate(['/menu-table']); 
  }

  navigateToMenucard() {
    this.router.navigate(['/menu-card']);
  }

  navigateToCreateadmin() {
    this.router.navigate(['/create-admin']); 
  }


}
